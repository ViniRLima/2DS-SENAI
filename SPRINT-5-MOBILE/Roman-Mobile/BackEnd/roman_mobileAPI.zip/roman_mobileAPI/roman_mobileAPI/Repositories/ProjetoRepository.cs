﻿using Microsoft.EntityFrameworkCore;
using roman_mobileAPI.Contexts;
using roman_mobileAPI.Domains;
using roman_mobileAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace roman_mobileAPI.Repositories
{
    public class ProjetoRepository : IProjetoRepository
    {

        
      RomanContext ctx = new RomanContext();

       /// <summary>
       /// Atualiza por id no escopo da URL
       /// </summary>
       /// <param name="idProjeto">idProjeto irá receber valores no parametro da função</param>
       /// <param name="ProjetoAtualizado">ProjetoAtualizado irá receber valores no parametro da função</param>
       public void Atualizar(short idProjeto, ProjetoDomain ProjetoAtualizado)
       {
           ProjetoDomain ProjetoBuscado = ctx.Projetos.Find(idProjeto); 

           if (ProjetoAtualizado.NomeProjeto != null)
           {
               ProjetoBuscado.NomeProjeto = ProjetoAtualizado.NomeProjeto;

               ctx.Projetos.Update(ProjetoBuscado);

               ctx.SaveChanges();
           }
       }

       /// <summary>
       /// Buscar pela id Projeto
       /// </summary>
       /// <param name="idProjeto">Objeto idProjeto irá buscar o id pelas informações orientadas</param>
       /// <returns>O idProjeto buscado</returns>
       public ProjetoDomain BuscarPorId(int idProjeto)
       {
           return ctx.Projetos.FirstOrDefault(e => e.IdProjeto == idProjeto);
       }

       /// <summary>
       /// Cadastra uma novo Projeto
       /// </summary>
       /// <param name="novoProjeto">Objeto novoProjeto com as informações que serão cadastradas</param>
       public void Cadastrar(ProjetoDomain novoProjeto)
       {
           // Adiciona uma novo Projeto
           ctx.Projetos.Add(novoProjeto);
           // Salva as informações que serão gravadas no banco de dados
           ctx.SaveChanges();
       }

       /// <summary>
       /// Deleta um Projeto
       /// </summary>
       /// <param name="idProjeto">Objeto idProjeto que será deletado</param>
       public void Deletar(int idProjeto)
       {
           //Deleta um Projeto
           ctx.Projetos.Remove(BuscarPorId(idProjeto));

           // Salva as informações que serão gravadas no banco de dados
           ctx.SaveChanges();
       }

       /// <summary>
       /// Lista de todas os Projetoes
       /// </summary>
       /// <returns>Lista de Projetoes</returns>
       public List<ProjetoDomain> Listar()
       {
           // Retorna uma lista de Projetos junto das suas Classes
           return ctx.Projetos.Include(e => e.IdUsuarioNavigation).ToList();
       }
      


    }
}
