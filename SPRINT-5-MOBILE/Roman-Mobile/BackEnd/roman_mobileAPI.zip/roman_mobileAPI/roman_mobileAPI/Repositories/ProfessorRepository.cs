﻿using Microsoft.EntityFrameworkCore;
using roman_mobileAPI.Contexts;
using roman_mobileAPI.Domains;
using roman_mobileAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace roman_mobileAPI.Repositories
{
    public class ProfessorRepository : IProfessorRepository
    {

        
       RomanContext ctx = new RomanContext();

        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="idProfessor">idProfessor irá receber valores no parametro da função</param>
        /// <param name="professorAtualizado">professorAtualizado irá receber valores no parametro da função</param>
        public void Atualizar(short idProfessor, ProfessorDomain professorAtualizado)
        {
            ProfessorDomain ProfessorBuscado = ctx.Professors.Find(idProfessor); 

            if (professorAtualizado.NomeProfessor != null)
            {
                ProfessorBuscado.NomeProfessor = professorAtualizado.NomeProfessor;

                ctx.Professors.Update(ProfessorBuscado);

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Buscar pela id Professor
        /// </summary>
        /// <param name="idProfessor">Objeto idProfessor irá buscar o id pelas informações orientadas</param>
        /// <returns>O idProfessor buscado</returns>
        public ProfessorDomain BuscarPorId(int idProfessor)
        {
            return ctx.Professors.FirstOrDefault(e => e.IdProfessor == idProfessor);
        }

        /// <summary>
        /// Cadastra uma novo Professor
        /// </summary>
        /// <param name="novoProfessor">Objeto novoProfessor com as informações que serão cadastradas</param>
        public void Cadastrar(ProfessorDomain novoProfessor)
        {
            // Adiciona uma novo Professor
            ctx.Professors.Add(novoProfessor);
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta um Professor
        /// </summary>
        /// <param name="idProfessor">Objeto idProfessor que será deletado</param>
        public void Deletar(int idProfessor)
        {
            //Deleta um Professor
            ctx.Professors.Remove(BuscarPorId(idProfessor));

            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas os Professores
        /// </summary>
        /// <returns>Lista de Professores</returns>
        public List<ProfessorDomain> Listar()
        {
            // Retorna uma lista de Professores junto das suas Classes
            return ctx.Professors.Include(e => e.IdUsuarioNavigation).ToList();
        }
       

    }
}
