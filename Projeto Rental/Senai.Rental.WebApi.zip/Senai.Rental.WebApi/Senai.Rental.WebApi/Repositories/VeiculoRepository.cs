﻿using Senai.Rental.WebApi.Domains;
using Senai.Rental.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Rental.WebApi.Repositories
{
    public class VeiculoRepository : IVeiculoRepository
    {
  private string stringConexao = @"Data Source=LAPTOP-TVA27R8T\SQLEXPRESS; initial catalog=T_Rental; integrated security=true";
        public void AtualizarIdCorpo(VeiculoDomain veiculoAtualizado)
        {
            if (veiculoAtualizado.nomeVeiculo != null)
            {
                using (SqlConnection con = new SqlConnection(stringConexao))
                {
                    string queryUpdateBody = @"UPDATE VEICULO 
                                               SET nomeVeiculo = @nomeVeiculo 
                                               WHERE idVeiculo = @idVeiculo";

                    using (SqlCommand cmd = new SqlCommand(queryUpdateBody, con))
                    {
                        cmd.Parameters.AddWithValue("@nomeVeiculo", veiculoAtualizado.nomeVeiculo);
                        cmd.Parameters.AddWithValue("@idVeiculo", veiculoAtualizado.idVeiculo);

                        con.Open();

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public void AtualizarIdUrl(int idVeiculo, VeiculoDomain veiculoAtualizado)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string queryUpdateUrl = @"UPDATE VEICULO 
                                          SET nomeVeiculo = @nomeVeiculo 
                                          WHERE idVeiculo = @idVeiculo";

                using (SqlCommand cmd = new SqlCommand(queryUpdateUrl, con))
                {
                    cmd.Parameters.AddWithValue("@nomeVeiculo", veiculoAtualizado.nomeVeiculo);
                    cmd.Parameters.AddWithValue("@idVeiculo", idVeiculo);

                    con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public VeiculoDomain BuscarPorId(int idVeiculo)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectById = @"SELECT idVeiculo,  
                                                  nomeVeiculo, 
                                                  idEmpresa, 
                                                  idModelo 
                                           FROM VEICULO
                                           WHERE idVeiculo = @idVeiculo";

                con.Open();

                SqlDataReader rdr;

                using (SqlCommand cmd = new SqlCommand(querySelectById, con))
                {
                    cmd.Parameters.AddWithValue("@idVeiculo", idVeiculo);

                    rdr = cmd.ExecuteReader();

                    if (rdr.Read())
                    {
                        VeiculoDomain veiculoBuscado = new VeiculoDomain
                        {

                            idVeiculo = Convert.ToInt32(rdr["idVeiculo"]),
                            nomeVeiculo = rdr["nomeVeiculo"].ToString(),
                            idEmpresa = Convert.ToInt32(rdr["idEmpresa"]),
                            idModelo = Convert.ToInt32(rdr["idModelo"])
                        
                        };

                        return veiculoBuscado;
                    }

                    return null;
                }
            }
        }

        public void Cadastrar(VeiculoDomain novoVeiculo)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string queryInsert = "INSERT INTO VEICULO (nomeVeiculo) VALUES (@nomeVeiculo)";

                con.Open();

                using (SqlCommand cmd = new SqlCommand(queryInsert, con))
                {

                    cmd.Parameters.AddWithValue("@nomeVeiculo", novoVeiculo.nomeVeiculo);

                    //Executa a query
                    cmd.ExecuteNonQuery();

                }
            }
        }

        public void Deletar(int idVeiculo)
        {
            
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
             
                string queryDelete = "DELETE FROM VEICULO WHERE idVeiculo = @idVeiculo";

              
                using (SqlCommand cmd = new SqlCommand(queryDelete, con))
                {
                
                    cmd.Parameters.AddWithValue("@idVeiculo", idVeiculo);

                  
                    con.Open();

              
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<VeiculoDomain> ListarTodos()
        {
            List<VeiculoDomain> listaVeiculos = new List<VeiculoDomain>();

           
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectAll = "SELECT idVeiculo, nomeVeiculo FROM Veiculo";

            
                con.Open();

              
                SqlDataReader rdr;

   
                using (SqlCommand cmd = new SqlCommand(querySelectAll, con))
                {
          
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
     
                        VeiculoDomain veiculo = new VeiculoDomain()
                        {


                            idVeiculo = Convert.ToInt32(rdr[0]),

                            nomeVeiculo = rdr[1].ToString()

                        };


                        listaVeiculos.Add(veiculo);

                    }
                }

            };

            return listaVeiculos;
        }
    }
}
