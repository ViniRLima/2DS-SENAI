﻿using Senai.Rental.WebApi.Domains;
using Senai.Rental.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Rental.WebApi.Repositories
{
    /// <summary>
    /// Classe responsável pelo repositórios dos clientes
    /// </summary>
    public class ClienteRepository : IClienteRepository
    {
     private string stringConexao = @"Data Source=LAPTOP-TVA27R8T\SQLEXPRESS; initial catalog=T_Rental; integrated security=true";
        public void AtualizarIdCorpo(ClienteDomain clienteAtualizado)
        {
            if (clienteAtualizado.nomeCLiente != null)
            {
                using (SqlConnection con = new SqlConnection(stringConexao))
                {
                    string queryUpdateBody = @"UPDATE CLIENTE  
                                               SET nomeCliente = @nomeCliente,  
                                                   sobrenomeCliente = @sobrenomeCliente, 
                                                   cnh = @cnh 
                                               WHERE idCliente = @idCliente";

                    using (SqlCommand cmd = new SqlCommand(queryUpdateBody, con))
                    {
                        cmd.Parameters.AddWithValue("@nomeCliente", clienteAtualizado.nomeCLiente);
                        cmd.Parameters.AddWithValue("@sobrenomeCliente", clienteAtualizado.sobrenomeCliente);
                        cmd.Parameters.AddWithValue("@cnh", clienteAtualizado.cnh);
                        cmd.Parameters.AddWithValue("@idCliente", clienteAtualizado.idCliente);

                        con.Open();

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public void AtualizarIdUrl(int idCliente, ClienteDomain clienteAtualizado)
        {
            using (SqlConnection con = new SqlConnection(stringConexao)) 
            {
                string queryUpdateUrl = @"UPDATE CLIENTE  
                                          SET nomeCliente = @nomeCliente, 
                                              sobrenomeCliente = @sobrenomeCliente, 
                                              cnh = @cnh  
                                          WHERE idCliente = @idCliente";

                using (SqlCommand cmd = new SqlCommand(queryUpdateUrl, con)) 
                {
                    cmd.Parameters.AddWithValue("@nomeCliente", clienteAtualizado.nomeCLiente);
                    cmd.Parameters.AddWithValue("@sobrenomeCliente", clienteAtualizado.sobrenomeCliente);
                    cmd.Parameters.AddWithValue("@cnh", clienteAtualizado.cnh);
                    cmd.Parameters.AddWithValue("@idCliente", idCliente);

                    con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public ClienteDomain BuscarPorId(int idCliente)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectById = @"SELECT nomeCliente, 
                                                  idCliente, 
                                                  sobrenomeCliente,  
                                                  cnh  
                                           FROM CLIENTE 
                                           WHERE idCliente = @idCliente";

                con.Open();

                SqlDataReader rdr;

                using (SqlCommand cmd = new SqlCommand(querySelectById,con)) 
                {
                    cmd.Parameters.AddWithValue("@idCliente", idCliente);

                    rdr = cmd.ExecuteReader();

                    if (rdr.Read()) 
                    {
                        ClienteDomain clienteBuscado = new ClienteDomain
                        {
                            idCliente = Convert.ToInt32(rdr["idCliente"]),
                            nomeCLiente = rdr["nomeCliente"].ToString(),
                            sobrenomeCliente = rdr["sobrenomeCliente"].ToString(),
                            cnh = Convert.ToDecimal(rdr["cnh"])
                        };

                        return clienteBuscado;
                    }

                    return null;
                }
            }
        }

        /// <summary>
        /// Cadastro um novo cliente
        /// </summary>
        /// <param name="novoCliente">Objeto novoCliente com as informações que serão cadastradas. </param>
        public void Cadastrar(ClienteDomain novoCliente)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string queryInsert = @"INSERT INTO CLIENTE (nomeCliente, sobrenomeCliente, cnh) 
                                                   VALUES (@nomeCliente, @sobrenomeCliente, @cnh)";

                con.Open();

                using (SqlCommand cmd = new SqlCommand(queryInsert,con)) 
                {
                    
                    cmd.Parameters.AddWithValue("@nomeCliente", novoCliente.nomeCLiente);
                    cmd.Parameters.AddWithValue("@sobrenomeCliente", novoCliente.sobrenomeCliente);
                    cmd.Parameters.AddWithValue("@cnh", novoCliente.cnh);

                    //Executa a query
                    cmd.ExecuteNonQuery();

                }
            }
        }

        public void Deletar(int idCliente)
        {
          
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                
                string queryDelete = "DELETE FROM CLIENTE WHERE idCliente = @idCliente";

              
                using (SqlCommand cmd = new SqlCommand(queryDelete, con))
                {
               
                    cmd.Parameters.AddWithValue("@idCliente", idCliente);

                   
                    con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Lista todos os clientes
        /// </summary>
        /// <returns>lista de clientes</returns>
        public List<ClienteDomain> ListarTodos()
        {
            List<ClienteDomain> listaClientes = new List<ClienteDomain>();

            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectAll = "SELECT idCliente, nomeCliente, sobrenomeCliente, cnh FROM CLIENTE";

                
                con.Open();

          
                SqlDataReader rdr;

               
                using (SqlCommand cmd = new SqlCommand(querySelectAll, con)) 
                {
                    
                  rdr =  cmd.ExecuteReader();

                    
                    while (rdr.Read()) 
                    {
                      
                        ClienteDomain cliente = new ClienteDomain()
                        {


                            idCliente = Convert.ToInt32(rdr["idCliente"]),

                            nomeCLiente = rdr["nomeCliente"].ToString(),

                            sobrenomeCliente = rdr["sobrenomeCliente"].ToString(),

                            cnh = Convert.ToDecimal(rdr["cnh"])
                        };

              
                        listaClientes.Add(cliente);
                    
                    }
                }

            };

            return listaClientes;
        }
    }
}
