﻿using Senai.Rental.WebApi.Domains;
using Senai.Rental.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.Rental.WebApi.Repositories
{
    public class AluguelRepository : IAluguelRepository
    {
        private string stringConexao = @"Data Source=LAPTOP-TVA27R8T\SQLEXPRESS; initial catalog=T_Rental; integrated security=true";
        public void AtualizarIdCorpo(AluguelDomain aluguelAtualizado)
        {
            if (aluguelAtualizado.aluguel != null)
            {
                using (SqlConnection con = new SqlConnection(stringConexao))
                {
                    string queryUpdateBody = @"UPDATE ALUGUEL 
                                               SET aluguel = @aluguel, 
                                                   datainicio = @datainicio, 
                                                   datafim = @datafim 
                                               WHERE idAluguel = @idAluguel";

                    using (SqlCommand cmd = new SqlCommand(queryUpdateBody, con))
                    {
                        cmd.Parameters.AddWithValue("@aluguel", aluguelAtualizado.aluguel);
                        cmd.Parameters.AddWithValue("@datainicio", aluguelAtualizado.datainicio);
                        cmd.Parameters.AddWithValue("@datafim", aluguelAtualizado.datafim);
                        cmd.Parameters.AddWithValue("@aluguel", aluguelAtualizado.idAluguel);


                        con.Open();

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        public void AtualizarIdUrl(int idAluguel, AluguelDomain aluguelAtualizado)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string queryUpdateUrl = @"UPDATE ALUGUEL  
                                          SET aluguel = @aluguel, 
                                              datainicio = @datainicio, 
                                              datafim = @datafim 
                                          WHERE idAluguel = @idAluguel";


                using (SqlCommand cmd = new SqlCommand(queryUpdateUrl, con))
                {
                    cmd.Parameters.AddWithValue("@aluguel", aluguelAtualizado.aluguel);
                    cmd.Parameters.AddWithValue("@datainicio", aluguelAtualizado.datainicio);
                    cmd.Parameters.AddWithValue("@datafim", aluguelAtualizado.datafim);
                    cmd.Parameters.AddWithValue("@idAluguel", idAluguel);

                    con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public AluguelDomain BuscarPorId(int idAluguel)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectById = @"SELECT idAluguel, 
                                                  idVeiculo,
                                                  idCliente, 
                                                  aluguel, 
                                                  datainicio, 
                                                  datafim  
                                           FROM ALUGUEL 
                                           WHERE idAluguel = @idAluguel";

                con.Open();

                SqlDataReader rdr;

                using (SqlCommand cmd = new SqlCommand(querySelectById, con))
                {
                    cmd.Parameters.AddWithValue("@idAluguel", idAluguel);

                    rdr = cmd.ExecuteReader();

                    if (rdr.Read())
                    {
                        AluguelDomain aluguelBuscado = new AluguelDomain
                        {
                            idAluguel = Convert.ToInt32(rdr["idAluguel"]),
                            aluguel = Convert.ToInt32(rdr["aluguel"]),
                            idVeiculo = new VeiculoDomain()
                            {
                                idVeiculo = Convert.ToInt32(rdr["idVeiculo"])
                            },
                            idCliente = new ClienteDomain()
                            {
                                idCliente = Convert.ToInt32(rdr["idCliente"])
                            },
                            datainicio = Convert.ToDateTime(rdr["datainicio"]),
                            datafim = Convert.ToDateTime(rdr["datafim"])
   
                        };

                        return aluguelBuscado;
                    }

                    return null;
                }
            }
        }

        public void Cadastrar(AluguelDomain novoAluguel)
        {
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string queryInsert = @"INSERT INTO ALUGUEL (aluguel, datainicio, datafim) 
                                       VALUES (@aluguel, @datainicio ,@datafim)";

                con.Open();

                using (SqlCommand cmd = new SqlCommand(queryInsert, con))
                {

                    cmd.Parameters.AddWithValue("@aluguel", novoAluguel.aluguel);
                    cmd.Parameters.AddWithValue("@datainicio", novoAluguel.datainicio);
                    cmd.Parameters.AddWithValue("@datafim", novoAluguel.datafim);

                
                    cmd.ExecuteNonQuery();

                }
            }
        }

        public void Deletar(int idAluguel)
        {
       
            using (SqlConnection con = new SqlConnection(stringConexao))
            {
      
                string queryDelete = "DELETE FROM ALUGUEL WHERE idAluguel = @idAluguel";

              
                using (SqlCommand cmd = new SqlCommand(queryDelete, con))
                {
                
                    cmd.Parameters.AddWithValue("@idAluguel", idAluguel);

                    con.Open();

              
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public List<AluguelDomain> ListarTodos()
        {
            List<AluguelDomain> listaAluguel = new List<AluguelDomain>();

            using (SqlConnection con = new SqlConnection(stringConexao))
            {
                string querySelectAll = @"SELECT idAluguel, 
                                                 idVeiculo,  
                                                 idCliente,  
                                                 aluguel, 
                                                 datainicio, 
                                                 datafim 
                                          FROM Aluguel";

                con.Open();

                SqlDataReader rdr;

         
                using (SqlCommand cmd = new SqlCommand(querySelectAll, con))
                {
                    
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {

                        AluguelDomain aluguel = new AluguelDomain()
                        {
                            idAluguel = Convert.ToInt32(rdr["idAluguel"]),
                            aluguel = Convert.ToInt32(rdr["aluguel"]),
                            idVeiculo = new VeiculoDomain()
                            {
                                idVeiculo = Convert.ToInt32(rdr["idVeiculo"])
                            },
                           idCliente = new ClienteDomain()
                          {
                                idCliente = Convert.ToInt32(rdr["idCliente"]),
                          },
                            datainicio = Convert.ToDateTime(rdr["datainicio"]),
                            datafim = Convert.ToDateTime(rdr["datafim"])

                        };

                     
                        listaAluguel.Add(aluguel);

                    }
                }

            };

            return listaAluguel;
        }
    }
}
