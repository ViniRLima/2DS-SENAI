﻿using Senai.SP_Medical_Group.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Interfaces
{
    interface IConsultaRepository
    {
        
        /// <summary>
        /// Lista todos as Consultas
        /// </summary>
        /// <returns>Uma lista de Consultas</returns>
        List<ConsultaDomain> Listar();

        /// <summary>
        /// Busca uma Consulta através do seu id
        /// </summary>
        /// <param name="idConsulta">ID da Consulta que será buscado</param>
        /// <returns>Uma Consulta encontrada</returns>
        ConsultaDomain BuscarPorId(int idConsulta);

        /// <summary>
        /// Cadastra um nova Consulta
        /// </summary>
        /// <param name="novaConsulta">Objeto novaConsulta com os dados que serão cadastrados</param>
        void Cadastrar(ConsultaDomain novaConsulta);

        /// <summary>
        /// Atualiza uma Consulta existente
        /// </summary>
        /// <param name="idConsulta">ID da Consulta que será atualizada</param>
        /// <param name="consultaAtualizada">Objeto consultaAtualizada com as novas informações</param>
        void Atualizar(short idConsulta, ConsultaDomain consultaAtualizada);

        /// <summary>
        /// Deleta uma Consulta existente
        /// </summary>
        /// <param name="idConsulta">ID da Consulta que será deletada</param>
        void Deletar(int idConsulta);

        /// <summary>
        /// Alterar a situação da consulta
        /// </summary>
        /// <param name="idConsulta">idConsulta informa qual o numero da consulta para alterar</param>
        /// <param name="status">status representado pela situação da consulta</param>
        public void AprovarRecusar(int idConsulta, string status);

        /// <summary>
        /// Adiciona uma nova descrição
        /// </summary>
        /// <param name="idConsulta">idConsulta paramentro do idConsulta</param>
        /// <param name="consulta">consulta paramentro referente a tabela consulta </param>
        void AdicionarDescricao(int idConsulta, ConsultaDomain consulta);
    }
}
