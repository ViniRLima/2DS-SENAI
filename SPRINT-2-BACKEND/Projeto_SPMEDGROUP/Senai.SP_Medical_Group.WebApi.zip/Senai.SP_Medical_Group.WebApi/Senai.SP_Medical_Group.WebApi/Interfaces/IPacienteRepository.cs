﻿using Senai.SP_Medical_Group.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Interfaces
{
    interface IPacienteRepository
    {

        
        /// <summary>
        /// Lista todos os Pacientes
        /// </summary>
        /// <returns>Uma lista de Pacientes</returns>
        List<PacienteDomain> Listar();

        /// <summary>
        /// Busca um Paciente através do seu id
        /// </summary>
        /// <param name="idPaciente">ID do Paciente que será buscado</param>
        /// <returns>Um Paciente encontrada</returns>
        PacienteDomain BuscarPorId(int idPaciente);

        /// <summary>
        /// Cadastra um novo Paciente
        /// </summary>
        /// <param name="novoPaciente">Objeto novoPaciente com os dados que serão cadastrados</param>
        void Cadastrar(PacienteDomain novoPaciente);

        /// <summary>
        /// Atualiza um Paciente existente
        /// </summary>
        /// <param name="idPaciente">ID do paciente que será atualizada</param>
        /// <param name="pacienteAtualizado">Objeto pacienteAtualizada com as novas informações</param>
        void Atualizar(short idPaciente, PacienteDomain pacienteAtualizado);

        /// <summary>
        /// Deleta uma Paciente existente
        /// </summary>
        /// <param name="idPaciente">ID da Paciente que será deletado</param>
        void Deletar(int idPaciente); 

        
    }
}
