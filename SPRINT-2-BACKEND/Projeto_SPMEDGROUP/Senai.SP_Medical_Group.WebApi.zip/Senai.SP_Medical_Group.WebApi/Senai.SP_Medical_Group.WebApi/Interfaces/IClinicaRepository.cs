﻿using Senai.SP_Medical_Group.WebApi.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Interfaces
{
    interface IClinicaRepository
    {

        /// <summary>
        /// Lista todos as Clinicas
        /// </summary>
        /// <returns>Uma lista de Clinicas</returns>
        List<ClinicaDomain> Listar();

        /// <summary>
        /// Busca uma Clinica através do seu id
        /// </summary>
        /// <param name="idClinica">ID da Clinica que será buscado</param>
        /// <returns>Uma Clinica encontrada</returns>
        ClinicaDomain BuscarPorId(int idClinica);

        /// <summary>
        /// Cadastra um nova Clinica
        /// </summary>
        /// <param name="novaClinica">Objeto novaClinica com os dados que serão cadastrados</param>
        void Cadastrar(ClinicaDomain novaClinica);

        /// <summary>
        /// Atualiza uma Clinica existente
        /// </summary>
        /// <param name="idClinica">ID da Clinica que será atualizada</param>
        /// <param name="clinicaAtualizada">Objeto clinicaAtualizada com as novas informações</param>
        void Atualizar(short idClinica, ClinicaDomain clinicaAtualizada);

        /// <summary>
        /// Deleta uma Clinica existente
        /// </summary>
        /// <param name="idClinica">ID da clinica que será deletada</param>
        void Deletar(int idClinica);

    }
}
