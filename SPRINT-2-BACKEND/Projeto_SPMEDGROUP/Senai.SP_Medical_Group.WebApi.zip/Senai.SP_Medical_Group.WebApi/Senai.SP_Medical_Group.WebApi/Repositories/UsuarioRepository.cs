﻿using Microsoft.EntityFrameworkCore;
using Senai.SP_Medical_Group.WebApi.Contexts;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
       
        MedGroupContext ctx = new MedGroupContext();


        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="IdUsuario">IdUsuario irá receber valores no parametro da função</param>
        /// <param name="usuarioAtualizado">usuarioAtualizado irá receber valores no parametro da função</param>
        public void Atualizar(int IdUsuario, UsuarioDomain usuarioAtualizado)
        {
            UsuarioDomain usuarioBuscado = ctx.Usuarios.Find(IdUsuario);

            if (usuarioAtualizado.Usuario1 != null)
            {
                usuarioBuscado.Usuario1 = usuarioAtualizado.Usuario1;

                ctx.Usuarios.Update(usuarioBuscado);

                ctx.SaveChanges();

            }
        }

        /// <summary>
        /// Busca pelo email e senha do Usuario
        /// </summary>
        /// <param name="email">parâmentro email para buscar</param>
        /// <param name="senha">parâmentro senha para buscar</param>
        /// <returns>email e senha do usuario cadastrado</returns>
        public UsuarioDomain BuscarPorEmailSenha(string email, string senha)
        {
            //Retorna email e senha junto do tipo de usuario cadastrado
            //return ctx.Usuarios.Include(e => e.IdTipoUsuarioNavigation).FirstOrDefault(e => e.Email == email && e.Senha == senha);
            return ctx.Usuarios.FirstOrDefault(e => e.Email == email && e.Senha == senha);
        }

        /// <summary>
        /// Buscar pelo id Usuario
        /// </summary>
        /// <param name="IdUsuario">Objeto IdUsuario irá buscar o id pelas informações orientadas</param>
        /// <returns>O IdUsuario buscado</returns>
        public UsuarioDomain BuscarPorId(int IdUsuario)
        {
            //Retorna o id buscado na consulta
            return ctx.Usuarios.FirstOrDefault(e => e.IdUsuario == IdUsuario);
        }

        /// <summary>
        /// Cadastra um novo usuario
        /// </summary>
        /// <param name="novoUsuario">Objeto novoUsuario com as informações que serão cadastradas</param>
        public void Cadastrar(UsuarioDomain novoUsuario)
        {
            // Adiciona um novo Usuario
            ctx.Usuarios.Add(novoUsuario);

            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta um usuario
        /// </summary>
        /// <param name="IdUsuario">Objeto IdUsuario que será deletado</param>
        public void Deletar(int IdUsuario)
        {
            //Deleta um Usuario
            ctx.Usuarios.Remove(BuscarPorId(IdUsuario));

            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas os Usuarios
        /// </summary>
        /// <returns>Lista de Usuarios</returns>
        public List<UsuarioDomain> Listar()
        {
            // Retorna uma lista de Usuarios e Tipo de Usuarios
            return ctx.Usuarios.Select(u => new UsuarioDomain()
            {
                IdUsuario = u.IdUsuario,
                Usuario1 = u.Usuario1,
                Email = u.Email,
                IdTipoUsuario = u.IdTipoUsuario,

                IdTipoUsuarioNavigation = new TipoUsuarioDomain()
                {
                    IdTipoUsuario = u.IdTipoUsuarioNavigation.IdTipoUsuario,
                    TipoUsuario1 = u.IdTipoUsuarioNavigation.TipoUsuario1
                }
            }).ToList();
        }


            /// <summary>
            /// Lista as consultas do medico ou do paciente
            /// </summary>
            /// <param name="idTipoUsuario">paramentro que informa o tipo de usuario do acesso</param>
            /// <param name="idUsuario">paramentro que informa o idUsuario que está acessando</param>
            /// <returns>Retorna uma lista de consultas medico ou paciente</returns>
            public List<ConsultaDomain> ListarMinhas(int idUsuario, int idTipoUsuario)
         {


            //idTipoUsuario igual a 2 se refere ao medico
            if (idTipoUsuario == 2)
            {
                //Criando um objeto medicos que recebem idUsuario e compara
                MedicoDomain medico = ctx.Medicos.FirstOrDefault(u => u.IdUsuario == idUsuario);

                //Informações de retorno da tabela consulta pegando o idMedico
                //Informações da consulta
                return ctx.Consulta.Select(c => new ConsultaDomain()
                {
                    IdMedico = c.IdMedico,
                    IdConsulta = c.IdConsulta,
                    IdPaciente = c.IdPaciente,
                    IdSituacao = c.IdSituacao,
                    DataHorario = c.DataHorario,
                    Consulta = c.Consulta,

                    //informações do médico
                    IdMedicoNavigation = new MedicoDomain()
                    {
                        IdMedico = c.IdMedicoNavigation.IdMedico,
                        Medico1 = c.IdMedicoNavigation.Medico1,
                        IdEspecialidade = c.IdMedicoNavigation.IdEspecialidade,
                        IdClinica = c.IdMedicoNavigation.IdClinica,
                        Crm = c.IdMedicoNavigation.Crm

                    }
                })
                    .Where(p => p.IdMedico == medico.IdMedico)
                    .ToList();




            }
            //idTipoUsuario igual a 3 se refere ao paciente
            else if (idTipoUsuario == 3)
            {
                //Criando um objeto pacientes que recebem idUsuario e compara
                PacienteDomain paciente = ctx.Pacientes.FirstOrDefault(u => u.IdUsuario == idUsuario);

                //Informações de retorno da tabela consulta pegando o idPaciente
                //Informações da consulta
                return ctx.Consulta.Select(c => new ConsultaDomain()
                {
                    IdConsulta = c.IdConsulta,
                    IdMedico = c.IdMedico,
                    IdPaciente = c.IdPaciente,
                    IdSituacao = c.IdSituacao,
                    DataHorario = c.DataHorario,
                    Consulta = c.Consulta,

                    //informações do médico
                    IdPacienteNavigation = new PacienteDomain()
                    {
                        IdPaciente = c.IdPacienteNavigation.IdPaciente,
                        Paciente1 = c.IdPacienteNavigation.Paciente1,
                        DataNascimento = c.IdPacienteNavigation.DataNascimento,
                        Rg = c.IdPacienteNavigation.Rg,
                        Cpf = c.IdPacienteNavigation.Cpf


                    }
                    })
                    .Where(p => p.IdPaciente == paciente.IdPaciente)
                    .ToList();

            }
            // Retorna nada se não tiver achado o tipo de usuario dentro do if
            else { return null; }

         }


       

    }
}
