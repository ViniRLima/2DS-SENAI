﻿using Senai.SP_Medical_Group.WebApi.Contexts;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Senai.SP_Medical_Group.WebApi.Repositories
{
    public class ClinicaRepository : IClinicaRepository
    {
        MedGroupContext ctx = new MedGroupContext();

        /// <summary>
        /// Atualiza por id no escopo da URL
        /// </summary>
        /// <param name="idClinica">idClinica irá receber valores no parametro da função</param>
        /// <param name="clinicaAtualizada">clinicaAtualizada irá receber valores no parametro da função</param>
        public void Atualizar(short idClinica, ClinicaDomain clinicaAtualizada)
        {
            ClinicaDomain ClinicaBuscada = ctx.Clinicas.Find(idClinica);

            if (clinicaAtualizada.Clinica1 != null)
            {
                ClinicaBuscada.Clinica1 = clinicaAtualizada.Clinica1;

                ctx.Clinicas.Update(ClinicaBuscada);

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Buscar pelo id Clinica
        /// </summary>
        /// <param name="idClinica">Objeto idClinica irá buscar o id pelas informações orientadas</param>
        /// <returns>O idClinica buscado</returns>
        public ClinicaDomain BuscarPorId(int idClinica)
        {
            //Retorna o id buscado na consulta
            return ctx.Clinicas.FirstOrDefault(e => e.IdClinica == idClinica);
        }

        /// <summary>
        /// Cadastra um nova Clinica
        /// </summary>
        /// <param name="novaClinica">Objeto novaClinica com as informações que serão cadastradas</param>
        public void Cadastrar(ClinicaDomain novaClinica)
        {
            // Adiciona uma Clinica
            ctx.Clinicas.Add(novaClinica);
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Deleta uma Clinica
        /// </summary>
        /// <param name="idCLinica">Objeto idCLinica que será deletado</param>
        public void Deletar(int idCLinica)
        {
            //Deleta uma Clinica
            ctx.Clinicas.Remove(BuscarPorId(idCLinica));
            // Salva as informações que serão gravadas no banco de dados
            ctx.SaveChanges();
        }

        /// <summary>
        /// Lista de todas as Clinicas
        /// </summary>
        /// <returns>Lista de Clinicas</returns>
        public List<ClinicaDomain> Listar()
        {
            // Retorna uma listar de Clinicas
            return ctx.Clinicas.ToList();
        }
    }
}
