﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class MedicoDomain
    {
        public MedicoDomain()
        {
            Consulta = new HashSet<ConsultaDomain>();
        }

        public int IdMedico { get; set; }
        public int? IdEspecialidade { get; set; }
        public int? IdClinica { get; set; }
        public int? IdUsuario { get; set; }
        public string Medico1 { get; set; }
        public string Crm { get; set; }

        public virtual ClinicaDomain IdClinicaNavigation { get; set; }
        public virtual Especialidade IdEspecialidadeNavigation { get; set; }
        public virtual UsuarioDomain IdUsuarioNavigation { get; set; }
        public virtual ICollection<ConsultaDomain> Consulta { get; set; }
    }
}
