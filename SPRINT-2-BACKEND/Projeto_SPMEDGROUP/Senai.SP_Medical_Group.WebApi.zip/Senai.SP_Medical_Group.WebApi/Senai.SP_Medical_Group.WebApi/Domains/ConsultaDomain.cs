﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class ConsultaDomain
    {
        public int IdConsulta { get; set; }
        public int? IdMedico { get; set; }
        public int? IdPaciente { get; set; }
        public int? IdSituacao { get; set; }
        public string Consulta { get; set; }
        public DateTime DataHorario { get; set; }

        public virtual MedicoDomain IdMedicoNavigation { get; set; }
        public virtual PacienteDomain IdPacienteNavigation { get; set; }
        public virtual SituacaoDomain IdSituacaoNavigation { get; set; }
    }
}
