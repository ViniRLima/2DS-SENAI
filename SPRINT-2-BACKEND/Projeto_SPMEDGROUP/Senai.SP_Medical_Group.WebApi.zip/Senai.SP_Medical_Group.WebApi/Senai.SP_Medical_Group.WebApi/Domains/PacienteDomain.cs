﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class PacienteDomain
    {
        public PacienteDomain()
        {
            Consulta = new HashSet<ConsultaDomain>();
        }

        public int IdPaciente { get; set; }
        public int? IdUsuario { get; set; }
        public string Paciente1 { get; set; }
        public DateTime DataNascimento { get; set; }
        public string Rg { get; set; }
        public string Cpf { get; set; }
        public string Endereco { get; set; }
        public string Telefone { get; set; }

        public virtual UsuarioDomain IdUsuarioNavigation { get; set; }
        public virtual ICollection<ConsultaDomain> Consulta { get; set; }
    }
}
