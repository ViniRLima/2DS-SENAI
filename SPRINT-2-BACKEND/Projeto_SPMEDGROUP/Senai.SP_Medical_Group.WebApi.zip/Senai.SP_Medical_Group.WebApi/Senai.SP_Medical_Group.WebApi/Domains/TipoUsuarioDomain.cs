﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Senai.SP_Medical_Group.WebApi.Domains
{
    public partial class TipoUsuarioDomain
    {
        public TipoUsuarioDomain()
        {
            Usuarios = new HashSet<UsuarioDomain>();
        }

        public int IdTipoUsuario { get; set; }
        public string TipoUsuario1 { get; set; }

        public virtual ICollection<UsuarioDomain> Usuarios { get; set; }
    }
}
