﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using Senai.SP_Medical_Group.WebApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// Controller responsavel pelos endpoints referentes aos Pacientes.
/// </summary>
namespace Senai.SP_Medical_Group.WebApi.Controllers
{
    //Define que o tipo de resposta da API será no formato JSON
    [Produces("application/json")]

    //Define que a rota de uma requisição será no formato domino/api/nomeController.
    // ex: http://localhost:5000/api/pacientes
    [Route("api/[controller]")]

    //Define que é um controlador de API.
    [ApiController]
    public class PacientesController : ControllerBase
    {

        /// <summary>
        /// Objeto _pacienteRepository que irá receber todos os metodos definidor na interface IPacienteRepository
        /// </summary>
        private IPacienteRepository _pacienteRepository { get; set; }

        /// <summary>
        /// Instancia um objeto _pacienteRepository para que haja a referencia aos metodos no repositorio.
        /// </summary>
        public PacientesController()
        {
            _pacienteRepository = new PacienteRepository();
        }

        /// <summary>
        /// Lista todos os Pacientes
        /// </summary>
        /// <returns>Uma lista de Pacientes e um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_pacienteRepository.Listar());
        }

        /// <summary>
        /// Busca o id Paciente
        /// </summary>
        /// <returns>O id buscado um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet("{idPaciente}")]
        public IActionResult BuscarPorId(int idPaciente)
        {
            return Ok(_pacienteRepository.BuscarPorId(idPaciente));
        }

        /// <summary>
        /// Cadastra um novo Paciente
        /// </summary>
        /// <returns>Um status code de que foi cadastrado o novo Paciente.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Cadastrar(PacienteDomain novoPaciente)
        {
            _pacienteRepository.Cadastrar(novoPaciente);

            return StatusCode(201);
        }

        /// <summary>
        /// Deleta um paciente selecionado pelo id
        /// </summary>
        /// <returns>Status code que foi deletado um medico escolhido pelo id.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpDelete("{idPaciente}")]
        public IActionResult Deletar(int idPaciente)
        {
            _pacienteRepository.Deletar(idPaciente);

            return StatusCode(204);
        }

        /// <summary>
        /// Atualizar um Paciente existente através do seu id
        /// </summary>
        /// <returns>Status code que foi atualizado.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPut("{idPaciente}")]
        public IActionResult Atualizar(short idPaciente, PacienteDomain pacienteAtualizado)
        {
            _pacienteRepository.Atualizar(idPaciente, pacienteAtualizado);

            return StatusCode(204);
        }

    }
}
