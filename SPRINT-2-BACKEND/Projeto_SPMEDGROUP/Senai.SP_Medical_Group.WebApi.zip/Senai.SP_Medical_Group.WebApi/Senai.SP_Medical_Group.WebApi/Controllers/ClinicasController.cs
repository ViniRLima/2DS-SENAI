﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using Senai.SP_Medical_Group.WebApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// Controller responsavel pelos endpoints referentes aos Clinicas.
/// </summary>
namespace Senai.SP_Medical_Group.WebApi.Controllers
{
    //Define que o tipo de resposta da API será no formato JSON
    [Produces("application/json")]

    //Define que a rota de uma requisição será no formato domino/api/nomeController.
    // ex: http://localhost:5000/api/clinicas
    [Route("api/[controller]")]

    //Define que é um controlador de API.
    public class ClinicasController : ControllerBase
    {

        /// <summary>
        /// Objeto _clinicaRepository que irá receber todos os metodos definidor na interface IClinicaRepository
        /// </summary>
        private IClinicaRepository _clinicaRepository { get; set; }

        /// <summary>
        /// Instancia um objeto _clinicaRepository para que haja a referencia aos metodos no repositorio.
        /// </summary>
        public ClinicasController()
        {
            _clinicaRepository = new ClinicaRepository();
        }

        /// <summary>
        /// Lista todas as Clinicas
        /// </summary>
        /// <returns>Uma lista de Clinicas e um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_clinicaRepository.Listar());
        }

        /// <summary>
        /// Busca o id Clinica
        /// </summary>
        /// <returns>O id buscado um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet("{idClinica}")]
        public IActionResult BuscarPorId(int idClinica)
        {
            return Ok(_clinicaRepository.BuscarPorId(idClinica));
        }

        /// <summary>
        /// Cadastra um nova Clinica
        /// </summary>
        /// <returns>Um status code de que foi cadastrado a nova CLinica.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Cadastrar(ClinicaDomain novaClinica)
        {
            _clinicaRepository.Cadastrar(novaClinica);

            return StatusCode(201);
        }

        /// <summary>
        /// Deleta uma cosulta selecionado pelo id
        /// </summary>
        /// <returns>Status code que foi deletado a consulta escolhido pelo id.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpDelete("{idClinica}")]
        public IActionResult Deletar(int idClinica)
        {
            _clinicaRepository.Deletar(idClinica);

            return StatusCode(204);
        }

        /// <summary>
        /// Atualizar uma Clinica existente através do seu id
        /// </summary>
        /// <returns>Status code que foi atualizado.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPut("{idClinica}")]
        public IActionResult Atualizar(short idClinica, ClinicaDomain clinicaAtualizada)
        {
            _clinicaRepository.Atualizar(idClinica, clinicaAtualizada);

            return StatusCode(204);
        }

    }
}
