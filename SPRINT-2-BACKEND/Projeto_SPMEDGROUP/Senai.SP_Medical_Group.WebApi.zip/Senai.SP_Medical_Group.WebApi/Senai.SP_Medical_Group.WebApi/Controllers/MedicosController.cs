﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Senai.SP_Medical_Group.WebApi.Domains;
using Senai.SP_Medical_Group.WebApi.Interfaces;
using Senai.SP_Medical_Group.WebApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

/// <summary>
/// Controller responsavel pelos endpoints referentes aos Medicos.
/// </summary>
namespace Senai.SP_Medical_Group.WebApi.Controllers
{
    //Define que o tipo de resposta da API será no formato JSON
    [Produces("application/json")]

    //Define que a rota de uma requisição será no formato domino/api/nomeController.
    // ex: http://localhost:5000/api/medicos
    [Route("api/[controller]")]

    //Define que é um controlador de API.
    [ApiController]
    public class MedicosController : ControllerBase
    {
        
        /// <summary>
        /// Objeto _medicoRepository que irá receber todos os metodos definidor na interface IMedicoRepository
        /// </summary>
        private IMedicoRepository _medicoRepository { get; set; }

        /// <summary>
        /// Instancia um objeto _medicoRepository para que haja a referencia aos metodos no repositorio.
        /// </summary>
        public MedicosController()
        {
            _medicoRepository = new MedicoRepository();
        }

        /// <summary>
        /// Lista todos os Medicos
        /// </summary>
        /// <returns>Uma lista de Medicos e um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet]
        public IActionResult Listar()
        {
            return Ok(_medicoRepository.Listar());
        }

        /// <summary>
        /// Busca o id Medico
        /// </summary>
        /// <returns>O id buscado um status code.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpGet("{idMedico}")]
        public IActionResult BuscarPorId(int idMedico)
        {
            return Ok(_medicoRepository.BuscarPorId(idMedico));
        }

        /// <summary>
        /// Cadastra um novo Medico
        /// </summary>
        /// <returns>Um status code de que foi cadastrado o novo Medico.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPost]
        public IActionResult Cadastrar(MedicoDomain novoMedico)
        {
            _medicoRepository.Cadastrar(novoMedico);

            return StatusCode(201);
        }

        /// <summary>
        /// Deleta um medico selecionado pelo id
        /// </summary>
        /// <returns>Status code que foi deletado um medico escolhido pelo id.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpDelete("{idMedico}")]
        public IActionResult Deletar(int idMedico)
        {
            _medicoRepository.Deletar(idMedico);

            return StatusCode(204);
        }

        /// <summary>
        /// Atualizar um Medico existente através do seu id
        /// </summary>
        /// <returns>Status code que foi atualizado.</returns>
        /// Authorize - Autorização de quem pode te acesso
        /// Roles - Os Autorizados (ADMINISTRADOR)
        [Authorize(Roles = "1")]
        [HttpPut("{idMedico}")]
        public IActionResult Atualizar(short idMedico, MedicoDomain medicoAtualizado)
        {
            _medicoRepository.Atualizar(idMedico, medicoAtualizado);

            return StatusCode(204);
        }


    }
}
